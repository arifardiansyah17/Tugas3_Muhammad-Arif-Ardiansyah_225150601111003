package com.example.tugas3;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private List<String> itemList = new ArrayList<>();
    private DatabaseHelper databaseHelper;
    private EditText inputItem;
    private boolean isItemVisible = false;  // Flag untuk cek status item

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        itemAdapter = new ItemAdapter(this, itemList);
        recyclerView.setAdapter(itemAdapter);

        inputItem = findViewById(R.id.inputItem);
        Button addButton = findViewById(R.id.btnAddItem);
        Button showItemsButton = findViewById(R.id.btnShowItems);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItemToDatabase();
            }
        });

        showItemsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isItemVisible) {
                    hideItems();
                    showItemsButton.setText("Tampilkan Item");
                } else {
                    loadItemsFromDatabase();
                    showItemsButton.setText("Sembunyikan Item");
                }
                isItemVisible = !isItemVisible;
            }
        });
    }

     private void addItemToDatabase() {
        String itemName = inputItem.getText().toString();
        if (!itemName.isEmpty()) {
            long id = databaseHelper.addItem(itemName);
            if (id > 0) {
                Toast.makeText(this, "Item berhasil ditambahkan", Toast.LENGTH_SHORT).show();

                inputItem.setText("");
            } else {
                Toast.makeText(this, "Gagal menambahkan item", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void loadItemsFromDatabase() {
        itemList.clear();
        Cursor cursor = databaseHelper.getAllItems();
        if (cursor.moveToFirst()) {
            do {
                String itemName = cursor.getString(cursor.getColumnIndex("name"));
                itemList.add(itemName);
            } while (cursor.moveToNext());
        }
        cursor.close();

        itemAdapter.notifyDataSetChanged();
    }

    private void hideItems() {
        itemList.clear();
        itemAdapter.notifyDataSetChanged();
    }
}
